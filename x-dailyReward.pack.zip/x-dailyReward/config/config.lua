Config = Config or {}

-- ███████╗██████╗░░█████╗░███╗░░░███╗███████╗░██╗░░░░░░░██╗░█████╗░██████╗░██╗░░██╗
-- ██╔════╝██╔══██╗██╔══██╗████╗░████║██╔════╝░██║░░██╗░░██║██╔══██╗██╔══██╗██║░██╔╝
-- █████╗░░██████╔╝███████║██╔████╔██║█████╗░░░╚██╗████╗██╔╝██║░░██║██████╔╝█████═╝░
-- ██╔══╝░░██╔══██╗██╔══██║██║╚██╔╝██║██╔══╝░░░░████╔═████║░██║░░██║██╔══██╗██╔═██╗░
-- ██║░░░░░██║░░██║██║░░██║██║░╚═╝░██║███████╗░░╚██╔╝░╚██╔╝░╚█████╔╝██║░░██║██║░╚██╗
-- ╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝░░░╚═╝░░░╚═╝░░░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝

Config.Framework = 'esx' -- You can choose between 'esx', 'oldesx', 'qb', 'oldqb', 'autodetect'
Config.SQL = 'oxmysql' -- You can choose between  'oxmysql', 'mysql-async', 'ghmattimysql' (If u are using 'mysql-async' or 'ghmattimysql' don't forget to adjust fxmanifest.lua)


-- ░██████╗░███████╗███╗░░██╗███████╗██████╗░░█████╗░██╗░░░░░
-- ██╔════╝░██╔════╝████╗░██║██╔════╝██╔══██╗██╔══██╗██║░░░░░
-- ██║░░██╗░█████╗░░██╔██╗██║█████╗░░██████╔╝███████║██║░░░░░
-- ██║░░╚██╗██╔══╝░░██║╚████║██╔══╝░░██╔══██╗██╔══██║██║░░░░░
-- ██████╔╝███████╗ ██║░╚███║███████╗██║░░██║██║░░██║███████╗
-- ░╚═════╝░╚══════╝╚═╝░░╚══╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝

Config.InventoryImages = "ox_inventory/web/images"  -- 'codem-inventory/html/itemimages', 'ox_inventory/web/images', 'qb-inventory/html/images', 'esx_inventoryhud/html/images'

Config.canClaimNonClaimedDays = false -- Allow players to claim non claimed days (if false, players can only claim the current day)

Config.openSettings = {
    useCommand = true, -- If you want to open the menu with a command, set this to true
    command = 'dailyreward', -- Command to open the menu
}

Config.Rewards = {
    {
        day    = 1, -- Day of the month
        image  = "", -- If you have set Config.InventoryImages, the image will appear automatically (if you want to do it manually, you can fill in the path to the image here, for example "cash.png")
        label  = 'Water', -- Label of the reward
        name   = 'water_bottle', -- Name of the reward (item name, vehicle name, weapon name, etc.)
        type   = 'item', -- Type of the reward ('item', 'cash', 'vehicle', 'box')
        amount = 1, -- Amount of the reward
    },
    {
        day    = 2, 
        label  = 'Cash',
        image  = "cash.png",
        type   = 'money', 
        amount = 500,
    },
    {
        day    = 3,
        image  = "",
        label  = 'Beer',
        name   = 'beer', 
        type   = 'item', 
        amount = 1, 
    },
    {
        day    = 4, 
        image  = "asea.png",
        label  = 'Asea', 
        name   = 'asea',
        type   = 'vehicle', 
    },
    {
        day    = 5, 
        image  = "",
        label  = 'Pistol', 
        name   = 'weapon_pistol',
        type   = 'weapon', 
        amount = 1,
    },
    {
        day    = 6,
        image  = "",
        label  = 'Plastic',
        name   = 'plastic',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 7,
        image  = "",
        label  = 'Metalscrap',
        name   = 'metalscrap',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 8,
        image  = "",
        label  = 'Iron',
        name   = 'iron',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 9,
        image  = "",
        label  = 'Glass',
        name   = 'glass',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 10, 
        image  = "box.png",
        label  = 'Box 1', 
        type   = 'box', 
        items  = {
            {
                image  = "", 
                label  = 'Cash',
                image  = "cash.png",
                type   = 'money', 
                amount = 500,
            },
            {
                image  = "",
                label  = 'Beer',
                name   = 'beer', 
                type   = 'item', 
                amount = 1, 
            },
        },
    },
    {
        day    = 11,
        image  = "",
        label  = 'Vodka',
        name   = 'vodka',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 12,
        image  = "",
        label  = 'Phone',
        name   = 'phone',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 13,
        image  = "",
        label  = 'Ifaks',
        name   = 'ifaks',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 14,
        image  = "",
        label  = 'Rolex',
        name   = 'rolex',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 15,
        image  = "",
        label  = 'Tablet',
        name   = 'tablet',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 16,
        image  = "",
        label  = 'Laptop',
        name   = 'laptop',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 17,
        image  = "",
        label  = 'Painkillers',
        name   = 'painkillers',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 18,
        image  = "",
        label  = 'Plastic',
        name   = 'plastic',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 19,
        image  = "",
        label  = 'Electronickit',
        name   = 'electronickit',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 20, 
        image  = "box.png",
        label  = 'Box 2', 
        type   = 'box', 
        items  = {
            {
                image  = "", 
                label  = 'Cash',
                image  = "cash.png",
                type   = 'money', 
                amount = 2000,
            },
            {
                image  = "",
                label  = 'Beer',
                name   = 'beer', 
                type   = 'item', 
                amount = 1, 
            },
        },
    },
    {
        day    = 21,
        image  = "",
        label  = 'Aluminumoxide',
        name   = 'aluminumoxide',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 22,
        image  = "",
        label  = 'Coke Package',
        name   = 'coke_small_brick',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 23,
        image  = "",
        label  = 'Repair Kit',
        name   = 'repairkit',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 24,
        image  = "",
        label  = 'Bandage',
        name   = 'bandage',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 25,
        image  = "",
        label  = 'Cleaning Kit',
        name   = 'cleaningkit',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 26,
        image  = "",
        label  = 'Firework',
        name   = 'firework1',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 27,
        image  = "",
        label  = 'Nitrous',
        name   = 'nitrous',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 28,
        image  = "",
        label  = 'Copper',
        name   = 'copper',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 29,
        image  = "",
        label  = 'Gold Chain',
        name   = 'goldchain',
        type   = 'item',
        amount = 1,
    },
    {
        day    = 30, 
        image  = "box.png",
        label  = 'Box 3', 
        type   = 'box', 
        items  = {
            {
                image  = "t20.png", 
                label  = 'T 20',
                image  = "t20.png",
                type   = 'vehicle'
            },
            {
                image  = "", 
                label  = 'Cash',
                image  = "cash.png",
                type   = 'money', 
                amount = 3500,
            },
        },
    },
}

Config.OnMenuOpen = function() -- This Executed when the menu is opened (useful to hide hud or any other elements on the screen)
    TriggerEvent('codem-blackhudv2:SetForceHide', true, true)
    TriggerEvent('codem-venicehud:SetForceHide', true)
    TriggerEvent("mHud:HideHud")
end

Config.OnMenuClose = function() -- This Executed when the menu is closed (useful to show hud again or any other elements on the screen)
    TriggerEvent('codem-blackhudv2:SetForceHide', false, false)
    TriggerEvent('codem-venicehud:SetForceHide', false)
    TriggerEvent("mHud:ShowHud")
end


-- ██╗░░░░░░█████╗░░█████╗░░█████╗░██╗░░░░░███████╗░██████╗
-- ██║░░░░░██╔══██╗██╔══██╗██╔══██╗██║░░░░░██╔════╝██╔════╝
-- ██║░░░░░██║░░██║██║░░╚═╝███████║██║░░░░░█████╗░░╚█████╗░
-- ██║░░░░░██║░░██║██║░░██╗██╔══██║██║░░░░░██╔══╝░░░╚═══██╗
-- ███████╗╚█████╔╝╚█████╔╝██║░░██║███████╗███████╗██████╔╝
-- ╚══════╝░╚════╝░░╚════╝░╚═╝░░╚═╝╚══════╝╚══════╝╚═════╝░

Config.Locales = {
    ['MENU_NAME'] = "DAILY REWARD",
    ['DAY'] = "DAY",
    ['NEXT_REWARD'] = "FOR NEXT REWARD"
}

-- ███╗░░██╗░█████╗░████████╗██╗███████╗██╗░█████╗░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗
-- ████╗░██║██╔══██╗╚══██╔══╝██║██╔════╝██║██╔══██╗██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝
-- ██╔██╗██║██║░░██║░░░██║░░░██║█████╗░░██║██║░░╚═╝███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░
-- ██║╚████║██║░░██║░░░██║░░░██║██╔══╝░░██║██║░░██╗██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗
-- ██║░╚███║╚█████╔╝░░░██║░░░██║██║░░░░░██║╚█████╔╝██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝
-- ╚═╝░░╚══╝░╚════╝░░░░╚═╝░░░╚═╝╚═╝░░░░░╚═╝░╚════╝░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░

Config.NotificationText = {
    ["CLAIMED_VEHICLE"] = {
        text = 'Claimed %s',
        timeout = 3000,
    },
    ["CLAIMED_ITEM"] = {
        text = 'Claimed %sx %s',
        timeout = 3000,
    },
    ["CLAIMED_CASH"] = {
        text = 'Claimed $%s cash',
        timeout = 3000,
    },
    ["CLAIMED_WEAPON"] = {
        text = 'Claimed %s',
        timeout = 3000,
    },
    ["CLAIMED_BOX"] = {
        text = 'Claimed %s',
        timeout = 3000,
    },
    ["NOT_CLAIM"] = {
        text = 'You can\'t claim this day',
        timeout = 3000,
    },
    ["COOLDOWN"] = {
        text = 'Wait a few seconds before trying again',
        timeout = 3000,
    },
}

Config.Notification = function(message, type, timeout, isServer, src) -- You can change here events for notifications
    if isServer then
        if Config.Framework == "esx" then
            TriggerClientEvent("esx:showNotification", src, message)
        else
            TriggerClientEvent('QBCore:Notify', src, message, type, timeout)
        end
    else
        if Config.Framework == "esx" then
            TriggerEvent("esx:showNotification", message)
        else
            TriggerEvent('QBCore:Notify', message, type, timeout)
        end
    end
end

-- ██████╗░███████╗██████╗░██╗░░░██╗░██████╗░
-- ██╔══██╗██╔════╝██╔══██╗██║░░░██║██╔════╝░
-- ██║░░██║█████╗░░██████╦╝██║░░░██║██║░░██╗░
-- ██║░░██║██╔══╝░░██╔══██╗██║░░░██║██║░░╚██╗
-- ██████╔╝███████╗██████╦╝╚██████╔╝╚██████╔╝
-- ╚═════╝░╚══════╝╚═════╝░░╚═════╝░░╚═════╝░

Config.Debug = false -- If you want to see more about what happens internally in the script use true.