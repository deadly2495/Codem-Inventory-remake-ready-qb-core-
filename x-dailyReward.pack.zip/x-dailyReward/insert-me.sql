DROP TABLE IF EXISTS `codem_dailyrewards`;
CREATE TABLE IF NOT EXISTS `codem_dailyrewards` (
  `identifier` varchar(65) DEFAULT NULL,
  `data` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;