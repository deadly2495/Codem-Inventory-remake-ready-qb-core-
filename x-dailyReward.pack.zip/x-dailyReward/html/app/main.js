const app = new Vue({
    el: '#app',
    data: {
        menuOpened: false,
        resourceName: 'x-dailyReward',
        itemSwiper: false,
        playerReceivedDays : [],
        Rewards: [],
        Label : '',
        nextRewardTime : '',
        currentDay : 0,
        itemSwiperIndex : 0,
        locales: {},
        canClaimNonClaimedDays: false,
        imagesFolder: {},
    },
    mounted() {
        window.addEventListener('keyup', this.keyHandler);

        window.addEventListener('message', (event) => {
            const data = event.data.payload;
            switch (event.data.action) {
                case "CHECK_NUI":
                    postNUI('LOADED');
                break;
                case "OPEN_MENU":
                    this.openMenu();
                break;
                case "SET_LOCALES":
                    this.locales = data;
                break;
                case "SET_CAN_CLAIM":
                    this.canClaimNonClaimedDays = data;
                break;
                case "SET_CLAIMED_DAYS":
                    this.playerReceivedDays = data;
                break;
                case "SET_REWARDS":
                    this.Rewards = data;

                    this.Rewards.forEach((item) => {
                        if (item.type == 'vehicle') {
                            fetch('./assets/car_images/' + item.image, { method: 'HEAD' })
                                .then(res => {
                                    if (!res.ok) {
                                        item.image = 'unmarked.png'
                                    }
                                }).catch(err => console.log('Error:', err));
                        }
                    })
                break;
                case "SET_INVENTORY_IMAGES":
                    this.imagesFolder = data;
                break;
            }
        });
    },
    methods: {
        openMenu() {
            this.menuOpened = true;
            this.currentTime();
            if (!this.itemSwiper) {
                setTimeout(() => {
                    this.dismantleSwiper();
                }, 300);
            }
        },

        dismantleSwiper() {
            if (this.itemSwiper) {
                this.itemSwiper.destroy();
            }

            this.itemSwiper = new Swiper("#mainswiper", {
                slidesPerView: 10,
                slidesPerGroup: 10,
                loop: false,
                speed : 500,
                spaceBetween: 16,
                navigation: {
                    nextEl: "#mainswiperleft",
                    prevEl: "#mainswiperright"
                },
                on: {
                    slideChange: this.slideChanged
                },
                pagination: {
                    el: ".custom-pagination",
                    clickable: true,
                }
            });
        },

        GetDailyItemLabel(item) {
            if (item.type == 'money') {
                return '$' + item.amount;
            }
        
            if (item.type == 'item' || item.type == 'weapon') {
                return item.amount + 'x ' + item.label;
            }
        
            if (item.type == 'vehicle') {
                return '1x ' + item.label;
            }
        
            if (item.type == 'box') {
                let combinedItems = '';
                for (let i = 0; i < item.items.length; i++) {
                    if (item.items[i].type == 'vehicle') {
                        combinedItems += '1x ' + item.items[i].label + ' - ';
                    } else if (item.items[i].type == 'item' || item.items[i].type == 'weapon') {
                        combinedItems += item.items[i].amount + 'x ' + item.items[i].label + ' - ';
                    } else if (item.items[i].type == 'money') {
                        combinedItems += '$' + item.items[i].amount + ' - ';
                    }
                }
                return combinedItems.slice(0, -2);
            }
        },        

        receiveReward(day, data) {
            this.Label = this.GetDailyItemLabel(data);
            if (this.playerReceivedDays.includes(day) ) {
                return;
            }else if (day == this.currentDay && !this.canClaimNonClaimedDays) {
                this.playerReceivedDays.push(day);
                postNUI("SAVE_PLAYER_DATA", {
                    data : this.playerReceivedDays,
                    item : data,
                    day : day,
                });
            }else if (this.canClaimNonClaimedDays) {
                if (day <= this.currentDay) {
                    this.playerReceivedDays.push(day);
                    postNUI("SAVE_PLAYER_DATA", {
                        data : this.playerReceivedDays,
                        item : data,
                        day : day,
                    });
                }
            }
            clicksound('click.wav');
        },

        GetDailyItemImage(item) {
            if (item.type == 'vehicle') {
                return `./assets/car_images/${item.image}`
            } else {
                return `./assets/item_images/${item.image}`
            }
        },

        currentTime() {
            let currentTime = new Date();
            let nextDay = new Date(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate() + 1, 0, 0, 0);
            let difference = nextDay - currentTime;
            let seconds = Math.floor(difference / 1000);
            let minutes = Math.floor(seconds / 60);
            let hours = Math.floor(minutes / 60);
            seconds %= 60;
            minutes %= 60;
            this.nextRewardTime = `${hours}h ${minutes}m ${seconds}s`;
            this.currentDay = currentTime.getDate();
        },

        closeMenu() {
            this.menuOpened = !this.menuOpened;
            clicksound('click.wav');
            postNUI('CLOSE_MENU');
        },

        keyHandler(e) {
            if (e.which == 90) {
                this.itemSwiper.slidePrev();
            }else if (e.which == 88) {
                this.itemSwiper.slideNext();
            }else if (e.which == 27) {
                this.closeMenu();
            }
        },
    },
});

let audioPlayer = null;
function clicksound(val) {
    let audioPath = `./sound/${val}`;
    audioPlayer = new Howl({
        src: [audioPath]
    });
    audioPlayer.volume(0.4);
    audioPlayer.play();
}

var resourceName = 'x-dailyReward'

if (window.GetParentResourceName) {
    resourceName = window.GetParentResourceName()
    app.resourceName = resourceName
}

window.postNUI = async (name, data) => {
    try {
        const response = await fetch(`https://${resourceName}/${name}`, {
            method: 'POST',
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json'
            },
            redirect: 'follow',
            referrerPolicy: 'no-referrer',
            body: JSON.stringify(data)
        });
        return !response.ok ? null : response.json();
    } catch (error) {}
}