function openMenu()
    if nuiOpened then return end
    WaitNui()
    WaitCore()
    local playerClaimedDays = TriggerCallback('x-dailyReward:server:getPlayerClaimedDays')
    NuiMessage('SET_CLAIMED_DAYS',playerClaimedDays)
    NuiMessage('OPEN_MENU')
    SetNuiFocus(true, true)
    Config.OnMenuOpen()
    nuiOpened = true
end

exports('OpenMenu', openMenu)

function closeMenu()
    SetNuiFocus(false, false)
    Config.OnMenuClose()
    nuiOpened = false
end

exports('CloseMenu', closeMenu)