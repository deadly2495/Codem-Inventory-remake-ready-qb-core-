Config.Webhook = {
    ["ENABLED"] = false,
    ["NAME"] = "Daily Rewards",
    ["LINK"] = "", -- Discord Webhook Link (https://support.discord.com/hc/en-us/articles/228383668-Intro-to-Webhooks)"
    ["IMAGE"] = "https://cdn.discordapp.com/attachments/1025789416456867961/1106324039808594011/512x512_Logo.png"
}

function sendDiscordLogReward(data) 
    if not Config.Webhook.ENABLED then
        return 
    end

    local embed = {
        {
            ["title"] = "Daily Reward",
            ["description"] = "Player: **"..data.name.."**\nIdentifier: **"..data.identifier.."**\nDay: **"..data.day.."**\nItem: **"..data.item.."**",
            ["type"] = "rich",
            ["color"] = 2123412,
            ["footer"] = {
                ["text"] = "Daily Rewards",
            },
        }
    }
    PerformHttpRequest(Config.Webhook.LINK, function(err, text, headers) end, 'POST', json.encode({username = Config.Webhook.NAME, embeds = embed, avatar_url = Config.Webhook.IMAGE}), { ['Content-Type'] = 'application/json' })
end