const module = {
    namespaced: true,

    state: {},
    mutations: {}
};

export default module;
