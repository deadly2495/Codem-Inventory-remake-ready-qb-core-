const module = {
    namespaced: true,

    state: {
        societyAccount: {
            allow: false,
            jobdata: false,
            boss: false
        },
        currentPage: "",
        societyMoney: 0
    },
    mutations: {}
};

export default module;
