const module = {
    namespaced: true,

    state: {
        cryptodata: false
    },
    mutations: {}
};

export default module;
