const module = {
    namespaced: true,

    state: {
        savingdata: false,
        cancelSaving: false
    },
    mutations: {}
};

export default module;
