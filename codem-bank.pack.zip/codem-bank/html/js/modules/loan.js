const module = {
    namespaced: true,

    state: {
        loandata: false
    },
    mutations: {}
};

export default module;
