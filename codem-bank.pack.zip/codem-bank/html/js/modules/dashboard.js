const module = {
    namespaced: true,

    state: {
        currencyUnit: "$",
        playerData: false,
        iban: false,
        identifier: false,
        myJob: false,
        playerMoneyData: {},
        locales: false,
        atmAccount: false
    },
    mutations: {}
};

export default module;
